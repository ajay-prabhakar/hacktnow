 #include <stdio.h>
int main(){
	int ar[10],i;
	for(i=0;i<10;i++){
			printf("\nenter the number = ");
			scanf("%d",&ar[i]);
		
		}
		
		
	int k,j;
	scanf("\nenter the sum %d",&k);
	for(i=0;i<10;i++){
		for(j=i+1;j<10;j++){
				if((ar[i]+ar[j])==k){
					printf("the numbers are n1=%d n2=%d",ar[i],ar[j]);
					}
		
			}
		}
	

	}
	
