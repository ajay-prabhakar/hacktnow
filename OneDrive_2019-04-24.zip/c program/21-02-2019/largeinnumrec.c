#include <stdio.h>
int lrg(int);
int main(){
	int n;
	printf("enter the number = ");
	scanf("%d",&n);
	printf("\nsum of numbers in given number is = %d",lrg(n));
	}
	
	
int lrg(int n){
		int a=0,l=0;
		while(n!=0){
		a=n%10;
		if(a>l) l=a;
		n=n/10;
	}
	
		
return l;		
}

	
