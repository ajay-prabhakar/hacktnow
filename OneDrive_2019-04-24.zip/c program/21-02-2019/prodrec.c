#include <stdio.h>
int sumofd(int ,int);
int main(){
	int a,b;	
	printf("enter the number = ");
	scanf("%d %d",&a,&b);
	printf("\nsum of numbers in given number is = %d",sumofd(a,b));
	}
	
	
int sumofd(int a,int b){
		if(b==0) return 0;
		else return(a+sumofd(a,b-1));
		
		}
