#include <stdio.h>
int lrg(int);
int main(){

	
	int n;
	scanf("enter the number =%d",&n);
		
		lrg(n);
}
	
	
int lrg(int n){
	int a1 = 1, a2 = 2, a3 = 3;
	if(n<=3){
		if(n==1){
			printf("%d",a1);
			}
			
		else if(n==2){
			printf("%d %d",a1, a2);
			}
		else if(n==3){
			printf("%d %d %d",a1,a2,a3);
			}
		
		
		}
		
		
		
		else{
			int i,t;
			for(i=4; i<=n; i++){
				t=a1*2+a2;

				printf("%d\n",t);
				a1=a2;
				a2=a3;
				a3=t;
				
				
				}
			
			
			
			}	
			return 0;
	
		
}

	
