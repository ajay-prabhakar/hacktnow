 #include <stdio.h>
int main(){
	int ar[10],i;
	for(i=0;i<10;i++){
			printf("enter the number = ");
	scanf("%d",&ar[i]);
		
		}
		
		
	int l=ar[0];
		for(i=0;i<10;i++){
				if(ar[i]>l) l=ar[i];
		
		}
	

	printf("\n largest of numbers = %d",l);
	}
