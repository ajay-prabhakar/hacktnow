#include <stdio.h>
int sumofd(int);
int main(){
	int n;
	printf("enter the number = ");
	scanf("%d",&n);
	printf("\nsum of numbers in given number is = %d",sumofd(n));
	}
	
	
int sumofd(int n){

	

		
		}
