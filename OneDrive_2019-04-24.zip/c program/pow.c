#include<stdio.h>
#include<math.h>
int  main(){
int rad,area;
printf("\nenter the value of side");
scanf("\n%d",&rad);
area=pow(rad,3);


printf("\nvolume=%d\n",area);

return 0;
}
