#include<graphics.h>


using namespace std;

int main()
{
   int gd = DETECT, gm;
 
   initgraph(&gd, &gm, NULL);
 
   putpixel(25, 25, RED);
 
   getch();
   closegraph();
   return 0;
}
