#include<stdio.h>
int  main(){
int a,b,diff;
printf("\nenter the value of a,b");
scanf("\n%d%d",&a,&b);
diff=a-b;
if(diff<0){
diff=-diff;
printf("\n difference between=%d",diff);

}
else{
printf("\n difference between=%d",diff);
}


return 0;
}
