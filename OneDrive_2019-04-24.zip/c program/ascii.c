#include<stdio.h>
int  main(){
char num;
printf("\nenter the value of number");
scanf("%c",&num);


printf("\n ascii value is =%d\n",num);

return 0;
}
