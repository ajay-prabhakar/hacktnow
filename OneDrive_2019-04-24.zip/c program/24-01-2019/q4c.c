#include <stdio.h>


int main(){
    int i, j, n;
    printf("Enter the number of lines required: ");
    scanf("%d", &n);
    for(i=n;i<=i;i--){
		for (k=i; k>=i; k--)
		{
			printf("\t")
        for(j=1;j<=i;j++){
            printf("%d\t", j);
        }
        
	}
   	printf("\n");
    }
    return 0;
}
q		
