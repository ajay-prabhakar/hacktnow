#include<stdio.h>

int main()
{
int n;
int ecount=0,ocount=0,zcount=0;
scanf("%d\n",&n);
while(n<999){
	
if(n==0){
	
	zcount+=1;
}
else if(n>x10){
	ecount+=1;
}
else{

ocount+=1;
}



scanf("%d\n",&n);
}
printf("poss=%d zero=%d negitive=%d",ecount,zcount,ocount);
}
	
