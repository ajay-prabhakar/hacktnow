#include <stdio.h>
 
int main()
{
    float number, sum = 0, i;
 
    printf("\n enter the number ");
    scanf("%f", &number);
    for (i = 1; i <= number; i++)
    {
        sum = sum + (1 / i);
        
    }
    printf("\n The sum of the given series is %f", sum);
	

}


