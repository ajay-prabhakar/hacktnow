#include<stdio.h>
int  main(){
int a,b;
printf("\nenter the value of a,b");
scanf("\n%d%d",&a,&b);
if(a>b){
printf("\n a is max number");

}
else{
printf("\n b is max  num");
}



return 0;
}
