#include <stdio.h>
int rev(int , int);
int main(){
	int n,s;
	printf("enter the number = ");
	scanf("%d",&n);
	s=0;
	printf("\nthe reverse of given number is = %d",rev(n,s));
	}
	
	
int rev(int n, int s){
		if(n==0) return s;
		else {
			s=s*10+n%10;
			return(rev(n/10,s));
		
		}
		
		
	}
