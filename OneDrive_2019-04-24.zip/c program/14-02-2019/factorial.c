#include <stdio.h>
int fact(int);
int main(){
	int n;
	scanf("%d",&n);
	printf("factorial of numbers is = %d",fact(n));
	}
	
	
int fact(int n){
		if(n==0) return 1;
		else return(n*fact(n-1));
		
		}
