#include <stdio.h>

int main(){   
    long long int i,h,n,a,b,d,count1,count2,t2,t1;
    scanf("%lld\n",&h);

    for(i=0;i<h;i++){
    scanf("%lld %lld %lld %lld \n",&n,&a,&b,&d);
    t1=a;
    t2=a;
    while(t1!=b){
        if(t1==n){
            t1=t1-d;
            count1++;
        }
        else if(t1==1){
            t1=t1+d;
            count1++;
        }
        else{
            t1=t1+d;
            count1++;
        }
        
    }  
    
    while(t2!=b){
        if(t2==n){
            t2=t2-d;
            count2++;
        }
        else if(t2==1){
            t2=t2+d;
            count2++;
        }
        else{
            t2=t2-d;
            count2++;
        }
        
    }  
        
    if(count1>count2){
        printf("%lld\n",count2);
    }
    else{
        printf("%lld\n",count1);
    }
    }
    
}
