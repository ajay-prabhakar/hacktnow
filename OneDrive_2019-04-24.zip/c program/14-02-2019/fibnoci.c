#include <stdio.h>
int fib(int);
int main(){
	int n;
	printf("enter the number = ");
	scanf("%d",&n);
	printf("\n sum of before 2 numbers given number is = %d",fib(n));
	}
	
	
int fib(int n){
		if(n==0) return 0;
		else if(n==1) return 1;
		else return(fib(n-1)+fib(n-2));
		
		}
