#include <stdio.h>
int sum(int);
int main(){
	int n;
	scanf("%d",&n);
	printf("sum of numbers is = %d",sum(n));
	}
	
	
int sum(int n){
		if(n==0) return 0;
		else return(n+sum(n-1));
		
		}
