#include<stdio.h>
int main(){
int x,y;
printf("\ninput x,y:");
scanf("%d%d",&x,&y);
printf("\nx=%d,y=%d\n",x,y);
return 0;
}

