#include<stdio.h>
int main()
{
int a,b,c;
printf("enter any three numbers");
scanf("%3d%2d%3d", &a, &b, &c);
printf("%d\n%d\n%d\n" ,a,b,c);
}
