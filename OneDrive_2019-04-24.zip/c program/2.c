#include<stdio.h>
int main()
{
char line[100];
printf("Any sentence");
gets(line);
puts(line);
}
