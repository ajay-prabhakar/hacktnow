#include<stdio.h>
int  main(){
int a;
printf("\nenter the value up to where it happen");
scanf("%d",&a);
for(int i=0,i<=a,i++)
	{
	for(int j=0,j<=i,j++){
		printf("%d",j);
	}
	printf("\n");
}

}

return 0;
}
