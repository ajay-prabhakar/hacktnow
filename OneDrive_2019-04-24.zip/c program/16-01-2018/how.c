#include<stdio.h>
int main()
{
int a,b,c;
scanf("%d %d %d",&a,&b,&c);
do{
   if(b>=a){
       b=a+1;
   }   
else{
    a=b-1;
}
    if(c>=b){
        c=b+1;
    }
    else{
        b=c-1;
    }
    
    
    
    
}while(b>a && c>b);

printf("%d",a+b+c);


  return 0;
}

