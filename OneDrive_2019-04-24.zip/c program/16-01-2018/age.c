
#include<stdio.h>
int  main(){
int age;
printf("\nenter the value of age");
scanf("\n%d",&age);
if(age>18){
	printf("you are eligible to vote");

}
else{

	printf("you are not eligible");
}


return 0;
}
