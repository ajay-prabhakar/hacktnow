#include <stdio.h> 
int main() 
{ 

int a,b;
printf("\nenter the value of a,b");
scanf("\n%d%d",&a,&b);
printf("the choices are\n");
printf("1.sum 2.product 3.difference 4.quotient 5.reminder 6.max");
int x;
scanf("%d",&x);
   switch (x) 
   { 
       case 1: printf("the sum is=%d",a+b); 
               break; 
       case 2: printf("the product is=%d",a*b); 
                break; 
       case 3: printf("the difference is=%d",a-b); 
               break;
	

	case 4: printf("the quotient is=%d",a/b); 
               break;
	case 5: printf("the reminder is=%d",a%b); 
               break;
	case 6: {

if(a>b){ printf("a is greater");}


else{printf("b is greater");}
               break; 

}
       default: printf("Choice other out of range"); 
                break;   
   } 
   return 0; 
}
