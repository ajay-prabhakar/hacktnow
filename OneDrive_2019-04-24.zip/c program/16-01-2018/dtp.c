#include<stdio.h>
int  main(){
int prnt,price,type;
printf("\nenter the value of no of copies");
scanf("\n%d%d",&prnt,&type);
if(prnt>1){
	price=prnt*3-3+5;

}
else{

	price=3;
}
price=price+type*3;

printf("the price is = %d",price);
return 0;
}
