#include<stdio.h>
int main()
{
long long int n;
scanf("%lld",n);

if(n%2==1){

    printf("NO");
}
else if(n==2){

    printf("NO");
}
else{
    printf("YES");
}

  return 0;
}

