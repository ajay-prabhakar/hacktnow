#include<stdio.h>
int  main(){
int hour,price;
printf("if you want unlimited time in hour then print 24");
printf("\nenter the value of no of hour");
scanf("\n%d",&hour);

if(hour>=1 && hour<24){
	price=20*hour;

}
else if(hour==0.5){
	price=10;

}
else{

	price=90;

}


printf("the price is = %d",price);
return 0;
}
