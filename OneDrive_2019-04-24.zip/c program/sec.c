#include<stdio.h>
int  main(){
int sec,min,hrs;
printf("\nenter the value of sec");
scanf("\n%d",&sec);
min=sec/60;
hrs=min/60;
printf("\nhrs=%d,min=%d",hrs,min);

return 0;
}
