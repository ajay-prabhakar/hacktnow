#include<stdio.h>
int  main(){
int rad,area,per;
printf("\nenter the value of rad");
scanf("\n%d",&rad);
area=3.14*rad*rad;
per=2*3.14*rad;

printf("\narea=%d,perimeter=%d",area,per);

return 0;
}
