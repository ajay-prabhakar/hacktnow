#include<stdio.h>
#include<string.h>

typedef struct Student
{	int rollno;
    char name[25];
    int avg_mark;
    
  
}stud;




int main()
{
	
	int n;
	scanf("%d",&n);
	stud std[n];

	for(int i=0;i<n;i++){
		scanf("%d",&std[i].rollno);
		scanf("%s",std[i].name);
		scanf("%d",&std[i].avg_mark);
	}
	for(int i=0;i<n;i++){
		printf("%d ",std[i].rollno);
		printf("%s ",std[i].name);
		printf("%d \n",std[i].avg_mark);
	}
	
	
    
    return 0;
}
