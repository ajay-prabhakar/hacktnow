#include<stdio.h>
#include<string.h>

typedef struct Student
{	int book_id;
    char name[25];
    char author[25];
    int price;
    
  
}stud;


void read(stud *std,int n);

void print(stud *std,int n);


int main()
{
	
	int n;
	scanf("%d",&n);
	stud std[n];
	read(std,n);
	print(std,n);
	
    
    return 0;
}

void read(stud *std,int n){
	
	for(int i=0;i<n;i++){
		
		scanf("%d ",&std[i].book_id);
		scanf("%s ",std[i].name);
		scanf("%s",std[i].author);
		scanf("%d \n",&std[i].price);
		
		
		}
	
	
	
	
	}
	
	
	
void print(stud *std,int n){
		for(int i=0;i<n;i++){
		printf("%d ",std[i].book_id);
		printf("%s ",std[i].name);
		printf("%s ",std[i].author);

		
		printf("%d \n",std[i].price);
	}
	
	
	
}


