#include<stdio.h>
#include<string.h>

typedef struct Bank
{	int acc_no;
    char name[25];
    int type;
    int balence;
    
  
}stud;


void read(stud *std,int n);

void print(stud *std,int n);
void bsortDesc(stud *std, int s);



int main()
{
	
	int n;
	scanf("%d",&n);
	stud std[n];
	read(std,n);
	bsortDesc(std,n);
	print(std,n);
	
    
    return 0;
}

void read(stud *std,int n){
	
	for(int i=0;i<n;i++){
		
		scanf("%d ",&std[i].acc_no);
		scanf("%s ",std[i].name);
		scanf("%d ",&std[i].type);
		scanf("%d ",&std[i].balence);
		
		
		}
	
	
	
	
	}
	
	
	
void print(stud *std,int n){
	int input,flag=0;
	
	printf("ENTER ACC NO TO SEARch\n");
	
	scanf("%d",&input);
	
	for(int j=0;j<n;j++){
		
	if(input==std[j].acc_no){
		
		flag=1;
		
		printf("%d ",std[j].acc_no);
		printf("%s ",std[j].name);
		printf("%d ",std[j].type);
		printf("%d \n",std[j].balence);
	}
}

	if(flag==0){
		printf("ACCOUNT DOES NOT EXIST");
		}
	
}



void bsortDesc(stud *std, int s)
{
    int i, j;
    struct Bank temp;
    
    for (i = 0; i < s - 1; i++)
    {
        for (j = 0; j < (s - 1-i); j++)
        {
            if (std[j].acc_no < std[j + 1].acc_no)
            {
                temp = std[j];
                std[j] = std[j + 1];
                std[j + 1] = temp;
            } 
        }
    }
}



