
#include<stdio.h>
#include<string.h>

typedef struct Bank
{	int emp_no;
    char name[25];
    char type;
    int basic_pay;
    
  
}stud;


void read(stud *std,int n);

void display(stud *std,int n);
void bsortDesc(stud *std, int s);
void search(stud *std,int n);




int main()
{
	
	int n;
	scanf("%d",&n);
	stud std[n];
	read(std,n);
	bsortDesc(std,n);
	display(std,n);
	search(std,n);
	
    
    return 0;
}

void read(stud *std,int n){
	
	for(int i=0;i<n;i++){
		
		scanf("%d ",&std[i].emp_no);
		scanf("%s ",std[i].name);
		scanf("%c ",&std[i].type);
		scanf("%d ",&std[i].basic_pay);
		
		
		}
	
	
	
	
	}
	
	
	
void search(stud *std,int n){
	char input;
	int flag=0;
	
	printf("ENTER ACC NO TO SEARch\n");
	
	scanf("%c",&input);
	
	for(int j=0;j<n;j++){
		
	
		
		flag=1;
		if(input=='A'){
		printf("%d ",std[j].emp_no);
	}
	
		if(input=='B'){
		printf("%s ",std[j].name);
		
	}
		if(input=='C'){
		printf("%c ",std[j].type);
		
	}
		if(input=='D'){
		printf("%d \n",std[j].basic_pay);
		
	}
	
}

	if(flag==0){
		printf("ACCOUNT DOES NOT EXIST");
		}
	
}

void display(stud *std,int n){
		for(int i=0;i<n;i++){
		printf("%d ",std[i].emp_no);
		printf("%s ",std[i].name);
		printf("%c ",std[i].type);
		printf("%d \n",std[i].basic_pay);
	}
}


void bsortDesc(stud *std, int s)
{
    int i, j;
    struct Bank temp;
    
    for (i = 0; i < s - 1; i++)
    {
        for (j = 0; j < (s - 1-i); j++)
        {
            if (std[j].emp_no < std[j + 1].emp_no)
            {
                temp = std[j];
                std[j] = std[j + 1];
                std[j + 1] = temp;
            } 
        }
    }
}



