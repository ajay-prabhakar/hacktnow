#include<stdio.h>
int  main(){
int a;
printf("\nenter the value of a");
scanf("\n%d",&a);
if(a<10 && a>0){
printf("\n it is in this range only\n");

}
else{
printf("\n out of range\n");
}



return 0;
}
