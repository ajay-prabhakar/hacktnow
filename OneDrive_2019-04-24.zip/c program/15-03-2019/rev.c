

#include <stdio.h>

#include <string.h>

 

int main()

{

    char string[25], reverse_string[25] = {'\0'};

    int i, length = 0;

 

    printf("Enter a string \n");

    scanf("%s",string);

    for (i = 0; string[i] != '\0'; i++)

    {

        length++;

    }


    for (i = length - 1; i >= 0 ; i--)

    {

        reverse_string[length - i - 1] = string[i];

    }

  

 

    for ( i = 0; i < length ; i++)

    {

       

    }

       
    printf("%s is reverse of string \n", reverse_string);

}
