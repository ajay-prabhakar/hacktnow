#include<stdio.h>
int  main(){
int a,b,temp1,temp2;
printf("\nenter the value of a,b");
scanf("\n%d%d",&a,&b);
temp1=a;
temp2=b;
b=temp1;
a=temp2;
printf("\na=%db=%d",a,b);


return 0;
}
