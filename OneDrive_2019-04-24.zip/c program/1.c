 #include<stdio.h> 
int main()
{
char line[100];
printf("Any sentence");
scanf("%[^\n]",line); /* enter any sentence */
printf("%s", line);
}
