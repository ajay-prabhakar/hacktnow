#include <stdio.h>
#include <limits.h>
#include <math.h>

int main()
{
    int num;

    
    printf("Enter any number: ");
    scanf("%d", &num);

    
    int n=num^INT_MAX;
	long long binaryNumber = 0;
    int remainder, i = 1;
	while (n!=0)
    {
        remainder = n%2;
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }
		
		printf("%lld",binaryNumber);
    




    return 0;
}


