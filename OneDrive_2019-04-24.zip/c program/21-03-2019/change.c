#include <stdio.h>

int main()
{
    int num,k,newNum;

    
    
    scanf("%d %d", &num,&k);

	  
    newNum = num & (~(1 <<k));
    
    printf("%d ",newNum);

  




    return 0;
}



