#include <stdio.h>

int main()
{
    long long int num,zeros, i;

    scanf("%lld", &num);

    zeros = 0;
    

    for(i=0; i<32; i++)
    {
        
        if(num & 1){
		zeros++;
			}
	
        num >>= 1;
    }

    printf("%lld ", zeros);


    return 0;
}

