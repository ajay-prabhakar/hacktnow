#include <stdio.h>

int main()
{
    int num,zeros, i;

    
    printf("Enter any number: ");
    scanf("%d", &num);

    zeros = 0;
    

    for(i=1; i<=16; i++)
    {
        
        if(num & 1){
	
			}
		else{
				printf("%d ",i-1);
			
	             zeros++;

	 
	 }
       
        num >>= 1;
    }




    return 0;
}

