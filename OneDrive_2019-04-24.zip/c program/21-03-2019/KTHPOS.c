#include <stdio.h>

int main()
{
    int num, i,k;

    
    
    scanf("%d %d", &num,&k);
    

    
    
    

    for(i=0; i<32; i++)
    {
        if(i==k){
        if(num & 1){
				printf("1 ");
			}
			
			else{
				printf("0 ");
				}
				
		}
       
        num >>= 1;
    }




    return 0;
}


