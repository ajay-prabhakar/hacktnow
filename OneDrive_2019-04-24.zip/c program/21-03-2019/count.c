#include <stdio.h>

int main()
{
    int num,zeros, i;

    
    printf("Enter any number: ");
    scanf("%d", &num);

    zeros = 0;
    

    for(i=0; i<=16; i++)
    {
        
        if(num & 1){
	
			}
		else{
	             zeros++;

	 
	 }
       
        num >>= 1;
    }

    printf("Total zero bit is %d\n", zeros);


    return 0;
}
