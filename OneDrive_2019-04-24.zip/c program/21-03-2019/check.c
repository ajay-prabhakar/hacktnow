#include <stdio.h>

int main()
{
    int num, i,k;

    
    printf("Enter any number: ");
    scanf("%d", &num);
    printf("\nenter thw position: ");
	scanf("%d",&k);
    
    
    

    for(i=1; i<=16; i++)
    {
        if(i==k-1){
        if(num & 1){
				printf("YES");
			}
			
			else{
				printf("NO");
				}
				
		}
       
        num >>= 1;
    }




    return 0;
}


