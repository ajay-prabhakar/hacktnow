#include <stdio.h>
int main()
{
    long long n ,a , b;
    
    scanf("%lld %lld %lld", &n,&a,&b);
    printf("%lld",n-a);
}
