


#include <stdio.h>
int cube(int);
int main( )
{
	int a;
	printf("enter the side of the cube ");
	scanf("%d",&a);
	cube(a);
	
	return 0;
}

int cube(int a){
	 int vol;
	 vol=a*a*a;
	 printf("volume of the cube %d",vol);
	
	
	}

