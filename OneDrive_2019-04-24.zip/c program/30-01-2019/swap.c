 
#include <stdio.h>

int swap(int , int);

int main(){
	int x,y;
	scanf("%d%d",&x,&y);
	swap(x,y);
	return 0;

}

int swap(int x , int y){
	
	int t;
	t=x;
	x=y;
	y=t;
	printf("%d %d",x,y);
	return 0;
}
