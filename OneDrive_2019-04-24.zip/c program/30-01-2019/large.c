


#include <stdio.h>
int cube(int);
int main( )
{
	int a;
	printf("enter the value of num");
	scanf("%d",&a);
	cube(a);
	
	return 0;
}

int cube(int a){
	long long int d,l,count;
	l=0;
	d=a;
	 while(a>0){
		a=a/10;
		 count=count+1;

	
		}
a=d;

long long int i,pos;
for (i=0;i<count;i++){
	d=a%10;
	if(d>l)
	{
		
		pos=i;
	}
	a=a/10;
	
}
	
	

	printf("%lld",pos);
	return 0;
	
	
}

