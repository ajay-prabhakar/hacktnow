
#include <stdio.h>

int main( )
{	
	char ch;
	scanf("%c",&ch);
	while(ch!=" ")
	{
	int ocount=0 ,ccount=0;
	if(ch=="a" || ch=="e" || ch=="i" || ch=="o" || ch=="u")
		{
		
			ocount++;
		}
		else
		{
			
			ccount++;
			
		}	
			
			
			
			scanf("%c",ch);
		
		}
		
	printf("%d %d",ocount,ccount);
	
	
	return 0;
}

