
#include <stdio.h>
int cube(int);
int main( )
{
	int a;
	printf("enter the value of num");
	scanf("%d",&a);
	cube(a);
	
	return 0;
}

int cube(int a){
	 long long int d ,count;
		count=0;
	 while(a!=0){
		 d=a%10;
		 count=count*10+d;
		
		 a=a/10;
	
		 
		 
		 
		 }
	printf("%lld",count);
	return 0;
	
	
	}

